Contributors
============

Original Author: Daniel Cheatoshin

Current maintainers: 
* [Evgeniy](https://github.com/jonano614)
* [Frozen](https://github.com/xrdavies)

Contributors:
* [trueserve](https://github.com/trueserve)
* [sgaragagghu](https://github.com/sgaragagghu)



Thanks to Daniel Cheatoshin for creating xdag project.
Also thanks to all the people who reported bugs and suggested new features.

============  
PS: For those who contribute to this project but not listed here, please contact us to add you.
