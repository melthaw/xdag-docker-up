//
//  rpc_procedures.h
//  xdag
//
//  Created by Rui Xie on 3/29/18.
//  Copyright © 2018 xrdavies. All rights reserved.
//

#ifndef XDAG_RPC_PROCEDURES_H
#define XDAG_RPC_PROCEDURES_H

#ifdef __cplusplus
extern "C" {
#endif
	
/* init rpc procedures */
extern int xdag_rpc_init_procedures(void);

#ifdef __cplusplus
};
#endif
		
#endif //XDAG_TERMINAL_H
