#ifndef XDAG_TERMINAL_H
#define XDAG_TERMINAL_H

int terminal(void);
void *terminal_thread(void *arg);

#endif //XDAG_TERMINAL_H
