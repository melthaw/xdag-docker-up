#ifndef _SYS_SOCKET_H
#define _SYS_SOCKET_H

#include <winsock2.h>
#include <ws2tcpip.h>

#endif

