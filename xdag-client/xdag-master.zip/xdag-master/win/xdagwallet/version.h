#include "../../client/version.h"

#define VER_FILE_DESCRIPTION_STR    "GUI wallet for Dagger coin"
#define VER_FILE_VERSION            VERSION_MAJOR, VERSION_MINOR, VERSION_REVISION
#define VER_FILE_VERSION_STR        XDAG_VERSION

#define VER_PRODUCTNAME_STR         "Dagger coin"
#define VER_PRODUCT_VERSION         VER_FILE_VERSION
#define VER_PRODUCT_VERSION_STR     VER_FILE_VERSION_STR

#define VER_ORGANIZATION_NAME       "XDAG Community"

