// list of basic bulma extensions

require('bulma-extensions/bulma-accordion/accordion');
require('bulma-extensions/bulma-calendar/datepicker');
require('bulma-extensions/bulma-carousel/carousel');
require('bulma-extensions/bulma-iconpicker/iconPicker');
require('bulma-extensions/bulma-quickview/quickview');
require('bulma-extensions/bulma-slider/slider');
require('bulma-extensions/bulma-steps/steps');
require('bulma-extensions/bulma-tagsinput/tagsinput');
